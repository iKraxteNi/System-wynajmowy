var searchData=
[
  ['properties_23',['Properties',['../namespace_system__wynajmowy_1_1_properties.html',1,'System_wynajmowy']]],
  ['setdata_24',['setData',['../class_system__wynajmowy_1_1_class_function_d_b.html#a7171b78d88f376e927c70d5f3835d420',1,'System_wynajmowy::ClassFunctionDB']]],
  ['system_20wynajmowy_2eassemblyinfo_2ecs_25',['System wynajmowy.AssemblyInfo.cs',['../_system_01wynajmowy_8_assembly_info_8cs.html',1,'']]],
  ['system_5fwynajmowy_26',['System_wynajmowy',['../namespace_system__wynajmowy.html',1,'']]],
  ['system_5fwynajmowy_2eassemblyinfo_2ecs_27',['System_wynajmowy.AssemblyInfo.cs',['../net5_80-windows_2_system__wynajmowy_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../netcoreapp3_81_2_system__wynajmowy_8_assembly_info_8cs.html',1,'(Global Namespace)']]]
];
