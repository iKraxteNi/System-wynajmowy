var searchData=
[
  ['system_20wynajmowy_2eassemblyinfo_2ecs_76',['System wynajmowy.AssemblyInfo.cs',['../_system_01wynajmowy_8_assembly_info_8cs.html',1,'']]],
  ['system_5fwynajmowy_2eassemblyinfo_2ecs_77',['System_wynajmowy.AssemblyInfo.cs',['../net5_80-windows_2_system__wynajmowy_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../netcoreapp3_81_2_system__wynajmowy_8_assembly_info_8cs.html',1,'(Global Namespace)']]]
];
