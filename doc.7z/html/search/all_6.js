var searchData=
[
  ['getconnection_16',['GetConnection',['../class_system__wynajmowy_1_1_class_function_d_b.html#a2358b0a9f75ca2967df06ac3fd6cccd1',1,'System_wynajmowy::ClassFunctionDB']]],
  ['getdata_17',['GetData',['../class_system__wynajmowy_1_1_class_function_d_b.html#a78af0a5340ed924c2de8bce8cb994532',1,'System_wynajmowy::ClassFunctionDB']]]
];
