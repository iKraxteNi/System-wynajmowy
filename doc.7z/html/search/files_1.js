var searchData=
[
  ['assemblyinfo_2ecs_67',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
