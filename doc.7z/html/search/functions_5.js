var searchData=
[
  ['setdata_101',['setData',['../class_system__wynajmowy_1_1_class_function_d_b.html#a7171b78d88f376e927c70d5f3835d420',1,'System_wynajmowy::ClassFunctionDB']]]
];
