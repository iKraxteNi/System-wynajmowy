var searchData=
[
  ['_2enetcoreapp_2cversion_3dv3_2e1_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v3.1.AssemblyAttributes.cs',['../_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html',1,'']]],
  ['_2enetcoreapp_2cversion_3dv5_2e0_2eassemblyattributes_2ecs_1',['.NETCoreApp,Version=v5.0.AssemblyAttributes.cs',['../_system_01wynajmowy_2obj_2_debug_2net5_80-windows_2_8_n_e_t_core_app_00_version_0av5_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../_test_project1_2obj_2_debug_2net5_80_2_8_n_e_t_core_app_00_version_0av5_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)'],['../testy_01_systemu_01wynajmuj_xC4_x85cego_2obj_2_debug_2net5_80_2_8_n_e_t_core_app_00_version_0av5_80_8_assembly_attributes_8cs.html',1,'(Global Namespace)']]],
  ['_2enetframework_2cversion_3dv4_2e7_2e2_2eassemblyattributes_2ecs_2',['.NETFramework,Version=v4.7.2.AssemblyAttributes.cs',['../_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html',1,'']]]
];
